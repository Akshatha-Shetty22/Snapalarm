document.getElementById("setbutton").addEventListener("click",fun1);
function fun1()
{
    var ms=document.getElementById("setalarm").valueAsNumber;
    if(isNaN(ms))
        {
            alert("INVALID DATE");
            return;
        }
}