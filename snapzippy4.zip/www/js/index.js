document.getElementById("b1").addEventListener("click",fun);
document.getElementById("setbutton").addEventListener("click",fun1);
document.getElementById("back").addEventListener("click",fun2);
function fun()
{
    document.getElementById("Firstpage").style.display='none';
    document.getElementById("Secondpage").style.display='';
}
function fun2()
{
    document.getElementById("Secondpage").style.display='none';
    document.getElementById("Firstpage").style.display='';
}
function fun1()
{
    var ms=document.getElementById("setalarm").valueAsNumber;
    if(isNaN(ms))
        {
            alert("INVALID DATE");
            return;
        }
}