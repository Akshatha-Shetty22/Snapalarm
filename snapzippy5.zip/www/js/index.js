document.getElementById("b1").addEventListener("click",fun);
document.getElementById("setbutton").addEventListener("click",fun1);
document.getElementById("b6").addEventListener("click",stopAlarm);
document.getElementById("b5").addEventListener("click",snooze);
document.getElementById("back").addEventListener("click",fun2);
function fun()
{
    document.getElementById("Firstpage").style.display='none';
    document.getElementById("Secondpage").style.display='';
}
function fun2()
{
    document.getElementById("Secondpage").style.display='none';
    document.getElementById("Firstpage").style.display='';
}
 var alarmSound=new Audio();
alarmSound.src="/android_asset/www/music/mere.mp3";

    

function fun1()
{
    var ms=document.getElementById("setalarm").valueAsNumber;
    if(isNaN(ms))
        {
            alert("INVALID DATE");
            return;
        }
    var alarm=new Date(ms);
    var alarmTime=new Date(alarm.getUTCFullYear(),alarm.getUTCMonth(),alarm.getUTCDate(),alarm.getUTCHours(),alarm.getUTCMinutes(),alarm.getUTCSeconds());
    var differenceInMs=alarmTime.getTime()-(new Date()).getTime();
    if(differenceInMs<0)
        {
            alert("Specified time is already Passed!!!!!");
            return;
        }
    else{
        alert("Alarm Set");
    }
    setInterval(initAlarm,differenceInMs);
    
};
function initAlarm()
{
   
    alarmSound.play();
    document.getElementById("Secondpage").style.display="none";
    document.getElementById("Thirdpage").style.display='';
};

function stopAlarm()
{
     document.getElementById("Thirdpage").style.display="none";
    document.getElementById("Secondpage").style.display='';
    alarmSound.pause();
    alarmSound.src=""; 
    
};
function snooze()
{
     document.getElementById("Thirdpage").style.display="none";
    document.getElementById("Secondpage").style.display='';
    alarmSound.pause();
    alarmSound.src="";
    setTimeout(snoozeTime,120000);
    
};
function snoozeTime()
{
    alarmSound.src="/android_asset/www/music/mere.mp3";
}